class Book {
  String title;
  String author;
  double price;

  Book(this.title, this.author, this.price);

  void displayInfo() {
    print('Title: $title');
    print('Author: $author');
    print('Price: \$${price.toStringAsFixed(2)}');
  }

  void applyDiscount(double discount) {
    price -= discount;
    print('Price after discount: \$${price.toStringAsFixed(2)}');
  }
}

void main() {
  Book book = Book('Dart Programming', 'Ahmad Hafazi', 10.79);
  book.displayInfo();
  book.applyDiscount(5.00);
}
