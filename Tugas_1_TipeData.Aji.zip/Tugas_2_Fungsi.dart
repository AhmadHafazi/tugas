int jumlah(int a, int b) {
  return a + b;
}

void main() {
  int hasil = jumlah(278, 335);
  print('Hasil penjumlahan: $hasil');
}
