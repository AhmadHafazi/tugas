void main() {
  // Deklarasi variabel dengan tipe data yang berbeda
  int umur = 63;
  double tinggi = 1.15;
  String nama = 'Ahmad Hafazi';
  bool isMahasiswa = true;

  // Mencetak nilai variabel
  print('Umur: $umur');
  print('Tinggi: $tinggi');
  print('Nama: $nama');
  print('Is Mahasiswa: $isMahasiswa');
}
