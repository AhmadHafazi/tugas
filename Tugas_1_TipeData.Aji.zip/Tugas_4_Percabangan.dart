import 'dart:io';

void main() {
  print('Pilih operasi:');
  print('1. Penjumlahan');
  print('2. Pengurangan');
  print('3. Perkalian');
  print('4. Pembagian');

  String? pilihan = stdin.readLineSync();
  
  if (pilihan == null) {
    print('Pilihan tidak valid');
    return;
  }
  
  print('Masukkan dua angka:');
  double a = double.parse(stdin.readLineSync()!);
  double b = double.parse(stdin.readLineSync()!);

  double? hasil;

  switch (pilihan) {
    case '1':
      hasil = a + b;
      break;
    case '2':
      hasil = a - b;
      break;
    case '3':
      hasil = a * b;
      break;
    case '4':
      hasil = a / b;
      break;
    default:
      print('Pilihan tidak valid');
      return;
  }

  print('Hasil: $hasil');
}
